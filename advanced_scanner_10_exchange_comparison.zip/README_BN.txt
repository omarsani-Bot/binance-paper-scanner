KuCoin Advanced Crypto Scanner (Paper Trading only)

প্রয়োজন:
- Python 3.10+
- streamlit
- ccxt
- pandas

ইনস্টল:
pip install -r requirements.txt

চালু:
streamlit run kucoin_advanced_scanner.py

এই অ্যাপ public market data ব্যবহার করে; API key লাগে না।
এটি কোনো live order দেয় না। Paper portfolio Streamlit session-এর মধ্যে থাকে,
অ্যাপ/সেশন শেষ হলে স্থায়ীভাবে সংরক্ষিত নাও থাকতে পারে।
কোনো সিগনাল বা লাভের নিশ্চয়তা নেই।
