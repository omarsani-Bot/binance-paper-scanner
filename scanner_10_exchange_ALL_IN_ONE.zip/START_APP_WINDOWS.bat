@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo KuCoin Advanced Scanner - setup and launch
echo ==============================================
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py"
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo Python পাওয়া যায়নি। Python 3.10+ ইনস্টল করে আবার চালান।
    echo https://www.python.org/downloads/
    pause
    exit /b 1
  )
  set "PY=python"
)
%PY% -m pip install --upgrade pip
if errorlevel 1 goto error
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto error
%PY% -m streamlit run kucoin_advanced_scanner.py
if errorlevel 1 goto error
exit /b 0
:error
echo.
echo চালু করতে সমস্যা হয়েছে। উপরের error message-এর ছবি/লেখা পাঠান।
pause
exit /b 1
