KuCoin Advanced Crypto Scanner + 10 Exchange Price Comparison

Windows-এর জন্য সহজ পদ্ধতি:
1. ZIP ফাইলটি Extract করুন।
2. কম্পিউটারে Python 3.10 বা নতুন সংস্করণ ইনস্টল করুন। ইনস্টল করার সময় “Add Python to PATH” নির্বাচন করুন।
3. Extract করা ফোল্ডারে থাকা START_APP_WINDOWS.bat-এ ডাবল-ক্লিক করুন।
4. প্রথমবার প্রয়োজনীয় প্যাকেজ ইনস্টল হবে; এরপর Streamlit অ্যাপ চালু হবে। টার্মিনাল উইন্ডো বন্ধ করবেন না।

Mac/Linux:
1. Python 3.10+ ইনস্টল থাকতে হবে।
2. Terminal-এ এই ফোল্ডারে গিয়ে চালান: bash start_app.sh

ম্যানুয়াল পদ্ধতি (Windows/macOS/Linux):
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run kucoin_advanced_scanner.py

যদি python কমান্ড কাজ না করে, Windows-এ py -m pip / py -m streamlit ব্যবহার করে দেখুন।
অ্যাপ সাধারণত ব্রাউজারে http://localhost:8501 ঠিকানায় খোলে।

10টি এক্সচেঞ্জের পাবলিক স্পট মার্কেট ডেটা তুলনা করা হয়: KuCoin, Binance, Bybit, OKX,
Gate.io, Bitget, MEXC, CoinEx, HTX এবং BingX। সব এক্সচেঞ্জে সব পেয়ার নাও থাকতে পারে;
নেটওয়ার্ক/এক্সচেঞ্জ API সমস্যা হলে কোনো কোনো দাম পাওয়া যাবে না।

নোট: অ্যাপটি পাবলিক মার্কেট ডেটা ব্যবহার করে, API key লাগে না এবং কোনো live order দেয় না।
এটি paper-trading scanner; কোনো সিগনাল বা লাভের নিশ্চয়তা নেই। দামের ব্যবধান মানেই ঝুঁকিমুক্ত
arbitrage নয়—ফি, spread, slippage এবং liquidity বিবেচনা করতে হবে।
